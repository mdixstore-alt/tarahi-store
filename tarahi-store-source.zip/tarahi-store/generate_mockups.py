from pathlib import Path
import html
out=Path(__file__).parent/'public/assets';out.mkdir(exist_ok=True)
items=[
 ('cream','#ECE5D9','#F0ECE5','#C6BAAB','#272824','TARAHI','small'),
 ('black','#D5CFC3','#262627','#111113','#F7F1E6','AFTER\nHOURS','large'),
 ('sage','#E3E3D9','#A4B09D','#788874','#27342E','T.','small'),
 ('grey','#E7E4DF','#BDBCB9','#9C9D99','#272824','FORM\n& FEEL','large'),
 ('blue','#E0DDD8','#758DA4','#5F768A','#ECE8DD','SUNDAY\nCLUB','large'),
 ('brown','#DCD5CB','#7F6252','#5D473E','#EADFCF','tarahi.','small')
]
for slug,bg,shirt,shade,ink,art,scale in items:
    if '\n' in art:
        a,b=art.split('\n')
        graphic=f'<text x="440" y="442" font-size="{60 if scale=="large" else 38}" font-weight="800" text-anchor="middle" letter-spacing="-1.8" fill="{ink}">{html.escape(a)}</text><text x="440" y="500" font-size="{53 if scale=="large" else 38}" font-weight="800" text-anchor="middle" letter-spacing="-1.8" fill="{ink}">{html.escape(b)}</text>'
    else:graphic=f'<text x="440" y="467" font-size="{42 if scale=="small" else 56}" font-weight="700" text-anchor="middle" letter-spacing="{3 if scale=="small" else -1}" fill="{ink}">{html.escape(art)}</text>'
    svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="880" height="1040" viewBox="0 0 880 1040">
<defs>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="{bg}"/><stop offset="1" stop-color="#F4F0EA"/></linearGradient>
<linearGradient id="cloth" x1="0" y1="0" x2=".85" y2="1"><stop stop-color="{shirt}"/><stop offset=".48" stop-color="{shirt}"/><stop offset="1" stop-color="{shade}"/></linearGradient>
<filter id="blur"><feGaussianBlur stdDeviation="23"/></filter>
<filter id="shadow"><feDropShadow dx="14" dy="27" stdDeviation="20" flood-color="#30291F" flood-opacity=".22"/></filter>
<pattern id="grain" patternUnits="userSpaceOnUse" width="12" height="12"><circle cx="2" cy="2" r=".35" fill="#6e6356" opacity=".14"/></pattern>
</defs>
<rect width="880" height="1040" fill="url(#bg)"/>
<circle cx="710" cy="156" r="260" fill="#fff" opacity=".18"/>
<path d="M0 900 L880 760 880 1040H0Z" fill="#fff" opacity=".25"/>
<ellipse cx="463" cy="850" rx="310" ry="75" fill="#292015" opacity=".12" filter="url(#blur)"/>
<g filter="url(#shadow)" transform="rotate(-3 440 490)">
 <path d="M276 239 L359 210 Q395 234 440 239 Q487 236 522 210 L608 239 L754 357 L672 473 L602 418 L609 839 Q442 860 268 837 L277 418 L201 473 L130 356 Z" fill="url(#cloth)" stroke="{shade}" stroke-opacity=".5" stroke-width="3" stroke-linejoin="round"/>
 <path d="M359 209 Q390 274 440 274 Q489 274 522 209 L504 205 Q476 247 440 247 Q401 248 378 205 Z" fill="{shade}" opacity=".8"/>
 <path d="M377 204 Q404 240 440 240 Q473 240 504 204" fill="none" stroke="{shade}" stroke-width="8"/>
 <path d="M277 418 Q290 430 316 436 M603 418 Q580 432 557 439" stroke="{shade}" fill="none" stroke-opacity=".6" stroke-width="4"/>
 <path d="M316 438 L313 830 M557 435 L558 836" stroke="{shade}" stroke-width="2" opacity=".27"/>
 <path d="M280 827 Q437 844 607 828" fill="none" stroke="{shade}" stroke-width="4" opacity=".8"/>
 <path d="M143 364 L215 462 M740 363 L667 463" fill="none" stroke="{shade}" stroke-width="4" opacity=".6"/>
 <path d="M286 249 L337 252 M542 251 L598 249" stroke="white" stroke-width="5" opacity=".12"/>
 {graphic}
</g>
<rect width="880" height="1040" fill="url(#grain)" opacity=".45"/>
<text x="43" y="975" fill="#514C46" font-family="Arial,sans-serif" font-size="16" letter-spacing="4">TARAHI / STUDIO 01</text>
</svg>'''
    (out/f'tee-{slug}.svg').write_text(svg)
print('Generated',len(items),'original product mockups')
